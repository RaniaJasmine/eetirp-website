import { useState, useEffect } from 'react';
import { ArrowUpRight, Cpu, HardDrive, RefreshCw, Layers, CheckCircle2 } from 'lucide-react';
import { LiveApp } from '../types';

export default function SaaSLabs() {
  const [apps, setApps] = useState<LiveApp[]>([
    {
      id: 'app-01',
      name: 'Placement AI Platform',
      codename: 'Ecosystem App 01',
      category: 'ACCELERATOR',
      status: 'STABLE',
      version: 'v2.0.4',
      listeningPort: 3000,
      description: 'An intelligent engineering-centric placement acceleration engine mapping deep mechanical, electrical, and computer science competencies directly to modern tech roles.',
      terminalLogs: [
        '/dev/eetirp/apps $ cd placement-ai',
        'mounting core-engine v2.0.4...',
        '✓ competency_mapper_initialized',
        'placement-engine-v2 ~ listening on port :3000',
      ],
      stats: { cpu: 12, memory: '1.2 GB', requestCount: 1450, latency: 18 },
      competencies: ['Classical Statics', 'Thermal Systems', 'TypeScript Modules', 'LLM Competency Mapping', 'Docker Containers'],
    },
    {
      id: 'app-02',
      name: 'Kaura Hub',
      codename: 'Active Production',
      category: 'TELEMETRY',
      status: 'STABLE',
      version: 'v4.1.0',
      listeningPort: 443,
      description: 'Centralized workspace orchestrating hardware-software telemetry integrations, cloud deployment runtimes, and distributed project repositories.',
      terminalLogs: [
        '/root/kaurahub $ pull origin main',
        'syncing hardware_telemetry_layers...',
        'DEPLOYMENT STATUS: STABLE',
        'kaurahub-main server: listening on port :443',
      ],
      stats: { cpu: 28, memory: '3.4 GB', requestCount: 8900, latency: 8 },
      competencies: ['Hardware Telemetry', 'RTOS Scheduling', 'IoT Gateway Sync', 'Kubernetes Clusters', 'Continuous Integration'],
    },
  ]);

  const [activeDiagnosticId, setActiveDiagnosticId] = useState<string | null>(null);
  const [diagnosticProgress, setDiagnosticProgress] = useState<number>(0);
  const [diagnosticLogs, setDiagnosticLogs] = useState<string[]>([]);

  // Fluctuating metric values safely
  useEffect(() => {
    const timer = setInterval(() => {
      setApps((prevApps) =>
        prevApps.map((app) => ({
          ...app,
          stats: {
            ...app.stats,
            cpu: Math.max(5, Math.min(95, app.stats.cpu + Math.floor(Math.random() * 7) - 3)),
            latency: Math.max(4, Math.min(45, app.stats.latency + Math.floor(Math.random() * 3) - 1)),
            requestCount: app.stats.requestCount + Math.floor(Math.random() * 3),
          },
        }))
      );
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const runAppDiagnostics = (appId: string) => {
    if (activeDiagnosticId) return;

    setActiveDiagnosticId(appId);
    setDiagnosticProgress(0);
    setDiagnosticLogs(['Establishing diagnostic pipeline connection...']);

    const app = apps.find((a) => a.id === appId);
    if (!app) return;

    // Simulate multi-step compilation and check sequence
    const steps = [
      `Validating code signatures of ${app.name} (${app.version})...`,
      `Polling telemetry registers at port :${app.listeningPort}...`,
      `Running integration test on mapped competencies: [${app.competencies.slice(0, 2).join(', ')}]...`,
      `Telemetry metrics verified: Latency = ${app.stats.latency}ms, Mem = ${app.stats.memory}`,
      `AISTUDIO COR-ROUTE RE-VALIDATION COMPLETED. ALL CHANNELS PASS.`,
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setDiagnosticLogs((prev) => [...prev, `[INIT] ${steps[currentStep]}`]);
        setDiagnosticProgress((prev) => prev + 20);
        currentStep++;
      } else {
        clearInterval(interval);
        setApps((prevApps) =>
          prevApps.map((a) =>
            a.id === appId ? { ...a, status: 'STABLE' } : a
          )
        );
        setTimeout(() => {
          setActiveDiagnosticId(null);
          setDiagnosticProgress(0);
          setDiagnosticLogs([]);
        }, 3000);
      }
    }, 1000);
  };

  return (
    <section className="py-24 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto" id="services">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-4">
        <div>
          <span className="font-mono text-xs text-secondary uppercase tracking-[0.3em] mb-4 block">
            Incubation Center
          </span>
          <h2 className="font-sans text-3xl md:text-4xl font-semibold text-primary tracking-tight">
            SaaS Lab Operations
          </h2>
        </div>
        <p className="font-mono text-xs text-on-surface-variant max-w-sm leading-relaxed">
          Real-world deployment environments where code transitions from classical fundamentals to enterprise throughput pipelines.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-gutter">
        {apps.map((app) => (
          <div
            key={app.id}
            className="glass-surface p-6 md:p-8 rounded-lg border border-white/5 glow-border hover:border-secondary/20 transition-all duration-500 flex flex-col group relative"
          >
            {/* Header */}
            <div className="flex justify-between items-start mb-6">
              <span
                className={`px-3 py-1 border rounded text-[10px] font-mono tracking-widest uppercase ${
                  app.id === 'app-01'
                    ? 'border-secondary/30 text-secondary'
                    : 'border-green-500/30 text-green-400'
                }`}
              >
                {app.codename}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => runAppDiagnostics(app.id)}
                  disabled={!!activeDiagnosticId}
                  className="px-2 py-1 border border-white/10 rounded font-mono text-[10px] uppercase text-on-surface-variant hover:text-primary hover:border-secondary transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  title="Force Diagnostics"
                >
                  <RefreshCw className={`w-3 h-3 ${activeDiagnosticId === app.id ? 'animate-spin' : ''}`} />
                  diagnose
                </button>
                <a href="#onboarding" className="text-secondary/80 hover:text-secondary hover:translate-x-0.5 hover:-translate-y-0.5 transition-all">
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Interactive Diagnostic Portal takeover */}
            {activeDiagnosticId === app.id && (
              <div className="absolute inset-0 bg-[#00132e]/95 rounded-lg z-20 p-6 flex flex-col justify-between font-mono text-xs text-secondary select-none">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="font-bold text-primary">DIAGNOSTIC PIPELINE STATUS: {diagnosticProgress}%</span>
                    <span className="w-2.5 h-2.5 bg-yellow-400 rounded-full animate-ping"></span>
                  </div>
                  <div className="space-y-1.5 h-[180px] overflow-y-auto pt-2 text-on-surface-variant opacity-90 leading-relaxed">
                    {diagnosticLogs.map((log, i) => (
                      <p key={i}>&gt; {log}</p>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="w-full bg-surface-container-low h-1.5 rounded-full overflow-hidden mb-2">
                    <div
                      className="bg-secondary h-full transition-all duration-300 rounded-full"
                      style={{ width: `${diagnosticProgress}%` }}
                    ></div>
                  </div>
                  <p className="text-[10px] text-on-surface-variant/40">Securing environment keys. Please stand by...</p>
                </div>
              </div>
            )}

            {/* Terminal Window of the Card */}
            <div className="bg-surface-container-lowest rounded border border-white/5 p-4 mb-6 font-mono text-xs overflow-hidden select-none">
              <div className="flex justify-between items-center mb-3">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/20"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20"></div>
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/20"></div>
                </div>
                <div className="text-[9px] text-on-surface-variant/30 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                  STABLE v{app.version}
                </div>
              </div>
              <div className="space-y-1.5 opacity-80">
                {app.terminalLogs.map((log, i) => {
                  let logClass = "text-on-surface-variant";
                  if (log.startsWith('/')) logClass = "text-secondary terminal-glow";
                  if (log.includes('✓') || log.includes('STABLE')) logClass = "text-green-400 font-medium";
                  if (log.includes('listening')) logClass = "text-cyan-400 animate-pulse";
                  return (
                    <p key={i} className={`font-mono leading-relaxed ${logClass}`}>
                      {log}
                    </p>
                  );
                })}
              </div>
            </div>

            {/* App Info */}
            <h3 className="font-sans text-xl font-medium text-primary mb-3">
              {app.name}
            </h3>
            <p className="text-on-surface-variant font-sans text-sm leading-relaxed mb-6 flex-grow">
              {app.description}
            </p>

            {/* Mapped Competencies Chips */}
            <div className="mb-6 flex flex-wrap gap-1.5">
              {app.competencies.map((comp, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 bg-surface-container border border-white/5 rounded text-[10px] font-mono text-on-secondary-container"
                >
                  {comp}
                </span>
              ))}
            </div>

            {/* Live Metrics Grid */}
            <div className="grid grid-cols-3 gap-3 border-t border-white/5 pt-4 bg-surface-container-lowest/20 -mx-6 -mb-6 p-4 rounded-b-lg">
              <div className="text-center">
                <p className="text-[10px] font-mono text-on-surface-variant/50 uppercase tracking-widest mb-1 flex items-center justify-center gap-1">
                  <Cpu className="w-3 h-3 text-secondary" /> CORE CPU
                </p>
                <p className="font-mono text-sm text-primary font-bold">{app.stats.cpu}%</p>
              </div>
              <div className="text-center border-x border-white/5">
                <p className="text-[10px] font-mono text-on-surface-variant/50 uppercase tracking-widest mb-1 flex items-center justify-center gap-1">
                  <HardDrive className="w-3 h-3 text-secondary" /> ALLOCATED
                </p>
                <p className="font-mono text-sm text-primary font-bold">{app.stats.memory}</p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-mono text-on-surface-variant/50 uppercase tracking-widest mb-1 flex items-center justify-center gap-1">
                  <Layers className="w-3 h-3 text-secondary" /> LATENCY
                </p>
                <p className="font-mono text-sm text-green-400 font-bold">{app.stats.latency}ms</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
