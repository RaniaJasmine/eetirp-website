import { useState, useEffect, ChangeEvent } from 'react';
import { Mail, Phone, ShieldCheck, HeartPulse, RefreshCw, LogOut, CheckCircle2, Award, Compass, ArrowRight } from 'lucide-react';
import { OnboardingDiagnostic } from '../types';

export default function DiagnosticOnboarding() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    segment: 'Core Engineering Student',
    inquiryMatrix: '',
  });

  const [activeSession, setActiveSession] = useState<OnboardingDiagnostic | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [diagnosticsLog, setDiagnosticsLog] = useState<string[]>([]);
  const [percent, setPercent] = useState(0);

  // Load existing session from localStorage if any
  useEffect(() => {
    const saved = localStorage.getItem('eetirp_diagnostic_onboarding');
    if (saved) {
      try {
        setActiveSession(JSON.parse(saved));
      } catch {
        localStorage.removeItem('eetirp_diagnostic_onboarding');
      }
    }
  }, []);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const executeDiagnosticsOnboarding = () => {
    if (!formData.fullName || !formData.email) return;

    setIsSubmitting(true);
    setPercent(0);
    setDiagnosticsLog(['Awaiting physical terminal layer coupling...']);

    const steps = [
      'Authenticating electronic mail domain key signature...',
      'Mapping designated sector coordinates to database indices...',
      'Analyzing suitability metrics aligned with EETIRP syllabus...',
      'Pre-allocating core container environments for micro-labs...',
      'Generating unique secure transmission token...',
    ];

    let current = 0;
    const interval = setInterval(() => {
      if (current < steps.length) {
        setDiagnosticsLog((prev) => [...prev, steps[current]]);
        setPercent((prev) => prev + 20);
        current++;
      } else {
        clearInterval(interval);

        // Calculate a simulated high-fidelity suitability score based on input
        const randomScore = Math.floor(Math.random() * 15) + 81; // 81 to 95%
        let indexCode = 'HIGH-ADAPTIVE';
        if (formData.segment === 'Tech Architect') indexCode = 'CORE-INFRASTRUCTURE';
        if (formData.segment === 'Enterprise Partner') indexCode = 'ORGANIZATIONAL-INTEGRATOR';
        
        const diagnosticId = `EETIRP-TX-${Math.floor(Math.random() * 900000 + 100000)}`;

        const newSession: OnboardingDiagnostic = {
          id: diagnosticId,
          fullName: formData.fullName,
          email: formData.email,
          segment: formData.segment,
          inquiryMatrix: formData.inquiryMatrix || 'No inquiry specifics provided.',
          timestamp: new Date().toLocaleDateString(),
          suitabilityScore: randomScore,
          suitabilityIndex: indexCode,
          status: 'COMPLETED',
          diagnosticsLog: [...steps, `SUITABILITY INDEX ESTABLISHED: ${indexCode} (${randomScore}% match)`],
        };

        localStorage.setItem('eetirp_diagnostic_onboarding', JSON.stringify(newSession));
        
        // Dispatch custom event to notify any interested components
        window.dispatchEvent(new Event('storage'));

        setTimeout(() => {
          setActiveSession(newSession);
          setIsSubmitting(false);
          setPercent(0);
          setDiagnosticsLog([]);
        }, 1500);
      }
    }, 1200);
  };

  const terminateSession = () => {
    if (window.confirm('Wipe local studio credentials and return to transmission mode?')) {
      localStorage.removeItem('eetirp_diagnostic_onboarding');
      setActiveSession(null);
      setFormData({
        fullName: '',
        email: '',
        segment: 'Core Engineering Student',
        inquiryMatrix: '',
      });
      window.dispatchEvent(new Event('storage'));
    }
  };

  return (
    <section className="py-32 px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto" id="onboarding">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        {/* Left Side: Instructions / Onboarding Detail */}
        <div>
          <span className="font-mono text-xs text-secondary uppercase tracking-[0.3em] mb-4 block">
            Transmission Protocol
          </span>
          <h2 className="font-sans text-3xl md:text-4xl font-semibold text-primary mb-8 tracking-tight leading-[1.2]">
            Initialize Onboarding Diagnostics
          </h2>
          <p className="text-on-surface-variant font-sans text-base leading-relaxed mb-12">
            Are you ready to join the elite hybrid ecosystem? Secure your slot in our next engineering cohort, activate compiler resources, or discuss enterprise integration pathways.
          </p>

          <div className="space-y-6">
            <div className="flex items-center gap-6 glass-surface p-6 rounded hover:border-secondary/20 transition-all duration-300">
              <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center border border-secondary/20 shadow-[0_0_8px_rgba(169,202,236,0.1)]">
                <Mail className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <p className="font-mono text-[10px] text-on-surface-variant/50 uppercase tracking-widest mb-1">
                  Electronic Mail
                </p>
                <a href="mailto:eetirpltd@gmail.com" className="font-sans text-base text-primary hover:text-secondary transition-colors">
                  eetirpltd@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-center gap-6 glass-surface p-6 rounded hover:border-secondary/20 transition-all duration-300">
              <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center border border-secondary/20 shadow-[0_0_8px_rgba(169,202,236,0.1)]">
                <Phone className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <p className="font-mono text-[10px] text-on-surface-variant/50 uppercase tracking-widest mb-1">
                  Direct Liaison
                </p>
                <a href="tel:+918088487801" className="font-sans text-base text-primary hover:text-secondary transition-colors">
                  +91 8088487801
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Interactive Diagnostics Container */}
        <div>
          {isSubmitting ? (
            /* Submitting / Active diagnostics scanning UI */
            <div className="glass-surface p-8 md:p-12 rounded-xl border border-white/10 space-y-8 min-h-[460px] flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-4">
                  <h3 className="font-mono text-sm tracking-widest text-primary uppercase flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-secondary animate-spin" />
                    COPTIC MATRIX ANALYTICS
                  </h3>
                  <span className="font-mono text-xs text-secondary">{percent}%</span>
                </div>
                
                {/* Simulated Log Feed */}
                <div className="space-y-2 font-mono text-[11px] text-on-surface-variant/80 border border-white/5 p-4 rounded bg-[#000d1f] h-[180px] overflow-y-auto leading-relaxed">
                  {diagnosticsLog.map((log, idx) => (
                    <p key={idx} className="flex items-center gap-2">
                      <span className="text-green-400">✓</span> {log}
                    </p>
                  ))}
                  <div className="w-1 bg-secondary h-3 inline-block animate-pulse"></div>
                </div>
              </div>

              <div>
                <div className="w-full bg-surface-container-low h-1 rounded-full overflow-hidden mb-3">
                  <div className="bg-secondary h-full transition-all duration-300" style={{ width: `${percent}%` }}></div>
                </div>
                <div className="flex items-center justify-between font-mono text-[10px] text-on-surface-variant/40 uppercase">
                  <span>Scanning competency overlaps</span>
                  <span>Port :3000 Active</span>
                </div>
              </div>
            </div>
          ) : activeSession ? (
            /* ACTIVE DIAGNOSED CANDIDATE DASHBOARD */
            <div className="glass-surface p-6 md:p-8 rounded-xl border border-secondary/20 shadow-[0_0_24px_rgba(169,202,236,0.1)] space-y-6">
              <div className="flex items-start justify-between border-b border-white/5 pb-4">
                <div>
                  <span className="font-mono text-[10px] text-green-400 border border-green-500/20 px-2 py-0.5 rounded tracking-wider uppercase bg-green-500/5">
                    DIAGNOSTICS CLEAR
                  </span>
                  <h3 className="font-sans text-xl font-bold text-primary mt-2">
                    {activeSession.fullName}
                  </h3>
                  <p className="font-mono text-[10px] text-on-surface-variant/50 mt-1 uppercase">
                    Ref ID: {activeSession.id}
                  </p>
                </div>
                <button
                  onClick={terminateSession}
                  className="p-2 border border-white/5 rounded text-on-surface-variant hover:text-red-400 hover:border-red-500/20 transition-all cursor-pointer"
                  title="Logout Session"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>

              {/* Suitability score block */}
              <div className="bg-surface-container-lowest border border-white/5 p-4 rounded flex items-center justify-between">
                <div>
                  <p className="font-mono text-[10px] text-on-surface-variant/50 uppercase tracking-widest">
                    Suitability Index Range
                  </p>
                  <p className="font-sans text-base text-primary font-medium mt-1">
                    {activeSession.segment}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[10px] text-secondary uppercase tracking-widest">
                    COMPATIBILITY
                  </p>
                  <p className="font-sans text-2xl font-bold text-green-400 mt-0.5">
                    {activeSession.suitabilityScore}%
                  </p>
                </div>
              </div>

              {/* Custom Action Roadmap */}
              <div className="space-y-4">
                <p className="font-mono text-[10px] text-on-surface-variant/60 uppercase tracking-widest">
                  Allocated Cohort Modules & Study Track
                </p>
                
                <div className="space-y-3 font-sans text-xs">
                  <div className="flex gap-3 items-start">
                    <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-primary">Syllabus Track Established</p>
                      <p className="text-[11px] text-on-surface-variant/70 mt-0.5">Your inquiry matrix was synced. Custom compiler tracks loaded.</p>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start">
                    <Award className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-primary">Core Engineering Competency Mapped</p>
                      <p className="text-[11px] text-on-surface-variant/70 mt-0.5">Matched directly to [Placement AI Platform] v2 nodes.</p>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start">
                    <Compass className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-primary">Bengaluru Sandbox Assignment Pending</p>
                      <p className="text-[11px] text-on-surface-variant/70 mt-0.5">Secure a direct callback at {activeSession.email}.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <a
                href="#services"
                className="w-full mt-2 py-4 bg-[#00214d] border border-secondary/20 hover:border-secondary text-primary font-mono text-xs uppercase tracking-[0.2em] font-medium rounded flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                Inspect SaaS Projects <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          ) : (
            /* STANDARD INTAKE DIRECT FORM */
            <form
              onSubmit={(e) => {
                e.preventDefault();
                executeDiagnosticsOnboarding();
              }}
              className="glass-surface p-8 md:p-12 space-y-8 rounded-xl border border-white/10"
            >
              {/* Full Name */}
              <div className="space-y-2">
                <label className="font-mono text-xs text-on-surface-variant uppercase tracking-widest">
                  Full Name
                </label>
                <input
                  name="fullName"
                  type="text"
                  required
                  className="w-full bg-background border-none border-b border-outline-variant focus:border-secondary focus:ring-0 text-primary px-0 py-3 transition-all placeholder:text-on-surface-variant/30 font-sans text-sm outline-none"
                  placeholder="Johnathan Doe"
                  value={formData.fullName}
                  onChange={handleChange}
                />
              </div>

              {/* Corporate Email */}
              <div className="space-y-2">
                <label className="font-mono text-xs text-on-surface-variant uppercase tracking-widest">
                  Corporate Email
                </label>
                <input
                  name="email"
                  type="email"
                  required
                  className="w-full bg-background border-none border-b border-outline-variant focus:border-secondary focus:ring-0 text-primary px-0 py-3 transition-all placeholder:text-on-surface-variant/30 font-sans text-sm outline-none"
                  placeholder="john@enterprise.com"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>

              {/* Designation Segment */}
              <div className="space-y-2">
                <label className="font-mono text-xs text-on-surface-variant uppercase tracking-widest">
                  Designation Segment
                </label>
                <select
                  name="segment"
                  className="w-full bg-background border-none border-b border-outline-variant focus:border-secondary focus:ring-0 text-primary px-0 py-3 transition-all font-sans text-sm outline-none"
                  value={formData.segment}
                  onChange={handleChange}
                >
                  <option className="bg-surface-container-highest">Core Engineering Student</option>
                  <option className="bg-surface-container-highest">Software Developer</option>
                  <option className="bg-surface-container-highest">Enterprise Partner</option>
                  <option className="bg-surface-container-highest">Tech Architect</option>
                </select>
              </div>

              {/* Inquiry Matrix */}
              <div className="space-y-2">
                <label className="font-mono text-xs text-on-surface-variant uppercase tracking-widest">
                  Inquiry Matrix
                </label>
                <textarea
                  name="inquiryMatrix"
                  className="w-full bg-background border-none border-b border-outline-variant focus:border-secondary focus:ring-0 text-primary px-0 py-3 transition-all placeholder:text-on-surface-variant/30 font-sans text-sm resize-none outline-none"
                  placeholder="Briefly describe your background or specific project interest..."
                  rows={4}
                  value={formData.inquiryMatrix}
                  onChange={handleChange}
                ></textarea>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={!formData.fullName || !formData.email}
                className="w-full py-5 bg-primary text-background font-mono uppercase tracking-[0.2em] font-bold rounded hover:bg-secondary cursor-pointer transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Initialize Onboarding Diagnostics
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
