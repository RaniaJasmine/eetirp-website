import { Code, Users, Terminal, MapPin, Shield, ArrowUp } from 'lucide-react';

export default function Footer() {
  const logoUrl = 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0Tb6eZNPswTOWvOMp-_Cr62CASvc3c1--t-f0c7jsDTf3DDa7VXGVV11ESxGD_HPDFE6RpScmJ370lwrrXmeazaZQYIj8m7hn0bJnYSqk3_XU5Dcss9V5eW-P-xrSNI2qfpfd9ie5Xo4uoeJkjFjwkdZpiCEgEQwCCuNfJ2qP6w02tLoQGSCGsEMAaHgvSpakzfOeNKfmFZIVxuo120cSRST7WO0Yiycj1foar3k9F_g1CBYb24k1YjOVtZMW5K-7OamqD3AzPLU';

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-surface-container-lowest border-t border-white/5 py-20 px-margin-mobile md:px-margin-desktop overflow-hidden relative" id="footer">
      <div className="max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10">
        
        {/* Brand Information */}
        <div className="md:col-span-2 space-y-8">
          <div className="flex items-center gap-3.5 select-none">
            <div className="w-10 h-10 rounded bg-white/5 flex items-center justify-center border border-white/10 p-1">
              <img
                alt="EETIRP Logo"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                src={logoUrl}
              />
            </div>
            <span className="font-sans text-lg font-extrabold tracking-tight text-white">
              EETIRP HYBRID TECH STUDIO
            </span>
          </div>

          <p className="text-on-surface-variant/80 max-w-sm font-sans text-sm leading-relaxed">
            Operating at the intersection of classical engineering and cloud-scale software architectures. Nurturing the next wave of industrial tech leaders and software architects.
          </p>

          {/* Social rails */}
          <div className="flex gap-4">
            <a
              href="#interactive-terminal"
              className="w-10 h-10 flex items-center justify-center border border-white/5 rounded-full text-on-surface-variant hover:text-white hover:border-secondary/40 hover:bg-surface-container-low transition-all"
              title="Terminal Interface"
            >
              <Code className="w-4.5 h-4.5" />
            </a>
            <a
              href="#onboarding"
              className="w-10 h-10 flex items-center justify-center border border-white/5 rounded-full text-on-surface-variant hover:text-white hover:border-secondary/40 hover:bg-surface-container-low transition-all"
              title="Ecosystem Cohorts"
            >
              <Users className="w-4.5 h-4.5" />
            </a>
            <a
              href="#services"
              className="w-10 h-10 flex items-center justify-center border border-white/5 rounded-full text-on-surface-variant hover:text-white hover:border-secondary/40 hover:bg-surface-container-low transition-all"
              title="Mainframe Telemetry"
            >
              <Terminal className="w-4.5 h-4.5" />
            </a>
          </div>
        </div>

        {/* Resources column */}
        <div className="space-y-6">
          <h4 className="font-mono text-[11px] text-white uppercase tracking-widest font-bold">
            Catalog & Cohort Resources
          </h4>
          <ul className="space-y-4 text-xs font-mono">
            <li>
              <a href="#services" className="text-on-surface-variant hover:text-secondary transition-colors">
                • Project Repositories
              </a>
            </li>
            <li>
              <a href="#interactive-terminal" className="text-on-surface-variant hover:text-secondary transition-colors">
                • Cohort Syllabus Tracks
              </a>
            </li>
            <li>
              <a href="#positioning" className="text-on-surface-variant hover:text-secondary transition-colors">
                • Architectures Document
              </a>
            </li>
            <li>
              <a href="#onboarding" className="text-on-surface-variant hover:text-secondary transition-colors">
                • Support Diagnostics
              </a>
            </li>
          </ul>
        </div>

        {/* Operations location column */}
        <div className="space-y-6 flex flex-col justify-between">
          <div>
            <h4 className="font-mono text-[11px] text-white uppercase tracking-widest font-bold mb-4 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-secondary" /> Workspace Coords
            </h4>
            <p className="font-mono text-xs text-on-surface-variant leading-relaxed pl-5">
              Tech Studio Operations,<br />
              Bengaluru, India
            </p>
          </div>

          <div className="flex items-center justify-between pt-8 border-t border-white/5">
            <p className="font-mono text-[10px] text-on-surface-variant/40 leading-relaxed uppercase">
              © 2026 EETIRP Ltd.<br />
              All rights reserved.
            </p>
            <button
              onClick={scrollToTop}
              className="p-2 border border-white/5 rounded bg-surface-container hover:border-secondary text-secondary hover:text-primary transition-all cursor-pointer"
              title="Return to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Decorative Blur Ambient Shadow in Bottom Right */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary/5 blur-[120px] pointer-events-none rounded-full"></div>
    </footer>
  );
}
